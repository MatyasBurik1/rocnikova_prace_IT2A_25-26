﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Konec : UserControl
    {
        public Konec()
        {
            InitializeComponent();
        }

        private void Cat_Click(object sender, RoutedEventArgs e)
        {
            if (!GameState.FoundCat)
            {
                GameState.FoundCat = true;
                MessageBox.Show("Našel jsi kočku! Gratuluji, splnil jsi úkol.");
            }
            else
            {
                MessageBox.Show("Kočku už jsi našel.");
            }
        }

        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow =
                (MainWindow)Application.Current.MainWindow;

            mainWindow.ChangeScene(new Menu());
        }
    }
}
