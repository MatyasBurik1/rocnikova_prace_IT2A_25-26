﻿using Microsoft.VisualBasic;
using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Ulice : UserControl
    {
        public Ulice()
        {
            InitializeComponent();
        }

        private void Policie_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Policie());
        }

        private void Bar_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Bar());
        }

        private void Alley_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;

            string password = Interaction.InputBox(
                "Zadej heslo:",
                "Brána do uličky",
                ""
            );

            if (password == "HESL0")
            {
                mainWindow.ChangeScene(new Ulicka());
            }
            else
            {
                mainWindow.ShowDialog("Špatné heslo!");
            }
        }
    }
}
