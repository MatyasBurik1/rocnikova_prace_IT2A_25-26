﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Bar : UserControl
    {
        public Bar()
        {
            InitializeComponent();
        }

        private void Bartender_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;


            if (!GameState.HasCoffee)
            {
                mainWindow.ShowDialog("Barman: Nejdřív mi přines kafe.");
                return;
            }

            if (!GameState.TalkedToBohous)
            {
                mainWindow.ShowDialog("Barman: Viděl jsem ji jak zabíhá do uličky vedle hospody, klíč má Bohuš u jukeboxu.");
                return;
            }


            else if (!GameState.HasBeer)
            {
                GameState.HasBeer = true;
                mainWindow.ShowDialog("Barman: Viděl jsem ji jak zabíhá do uličky vedle hospody, klíč má Bohuš u jukeboxu, tady máš pivo aby ti ho dal.");
                return;
            }

            else
            {
                mainWindow.ShowDialog("Barman: Zase ty? Takže ještě jednou heslo je HESL0.");
            }
        }

        private void Bohous_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;

            if (!GameState.HasBeer)
            {
                mainWindow.ShowDialog("Bohouš: Jdi pryč a neotravuj mě.");
                GameState.TalkedToBohous = true;
                return;
            }

            if (!GameState.HasKey)
            {
                GameState.HasKey = true;
                mainWindow.ShowDialog("Bohouš: Fajn... Heslo od branky je HESL0.");
                return;
            }

            mainWindow.ShowDialog("Bohouš: Už mě nech být.");
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.ChangeScene(new Ulice());
        }
    }
}