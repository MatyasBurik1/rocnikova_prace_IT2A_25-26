﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Ulice : UserControl
    {
        public Ulice()
        {
            InitializeComponent();
        }

        private void Policie_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Policie());
        }

        private void Bar_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Bar());
        }

        private void Alley_Click(object sender, RoutedEventArgs e)
        {
            if (!GameState.TalkedToBartender)
            {
                MessageBox.Show("Branka do uličky je zamčená. Možná by někdo věděl kód...");
                return;
            }

            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Ulicka());
        }
    }
}
