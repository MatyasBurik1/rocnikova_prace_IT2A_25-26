﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Bar : UserControl
    {
        public Bar()
        {
            InitializeComponent();
        }

        private void Bartender_Click(object sender, RoutedEventArgs e)
        {
            if (!GameState.HasCoffee)
            {
                MessageBox.Show("Barman: Nejdřív mi přines kafe.");
                return;
            }

            if (!GameState.TalkedToBartender)
            {
                GameState.TalkedToBartender = true;
                MessageBox.Show("Barman: Kočka utekla do uličky. Kód od branky je H3SL0.");
            }
            else
            {
                MessageBox.Show("Barman: Už jsem ti všechno řekl.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow =
                (MainWindow)Application.Current.MainWindow;

            mainWindow.ChangeScene(new Ulice());
        }
    }
}
