﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Konec : UserControl
    {
        public Konec()
        {
            InitializeComponent();
        }

        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow =
                (MainWindow)Application.Current.MainWindow;

            mainWindow.ChangeScene(new Menu());
        }
    }
}
