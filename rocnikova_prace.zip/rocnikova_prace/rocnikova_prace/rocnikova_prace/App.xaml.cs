﻿using System.Windows;

namespace rocnikova_prace
{
    public partial class App : Application
    {
    }
}
