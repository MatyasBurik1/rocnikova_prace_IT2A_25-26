﻿using System.Collections.Generic;

namespace rocnikova_prace.inventar
{
    public static class Inventar
    {
        public static List<string> Items { get; } = new List<string>();

        public static void AddItem(string item)
        {
            if (!Items.Contains(item))
            {
                Items.Add(item);
            }
        }
    }
}
