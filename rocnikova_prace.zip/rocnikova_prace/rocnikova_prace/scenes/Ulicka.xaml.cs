﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Ulicka : UserControl
    {
        public Ulicka()
        {
            InitializeComponent();
        }

        private void Cat_Click(object sender, RoutedEventArgs e)
        {
            if (!GameState.FoundCat)
            {
                GameState.FoundCat = true;
                MessageBox.Show("Našel jsi kočku!");
            }
            else
            {
                MessageBox.Show("Kočku už jsi našel.");
            }

            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Konec());
        }
    }
}
