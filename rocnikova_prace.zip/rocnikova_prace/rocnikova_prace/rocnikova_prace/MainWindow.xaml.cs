﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace rocnikova_prace
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            GameState.Reset();
            ChangeScene(new scenes.Menu());
        }
        public void ShowDialog(string text)
        {
            DialogText.Text = text;

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(3);

            timer.Tick += (s, e) =>
            {
                DialogText.Text = "";
                timer.Stop();
            };

            timer.Start();
        }

        public void ChangeScene(UserControl scene)
        {
            SceneHost.Content = scene;
        }
    }
}
