﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Policie : UserControl
    {
        public Policie()
        {
            InitializeComponent();
            if (GameState.HasCoffee)
            {
                kafe.Visibility = Visibility.Hidden;
            }
        }

        private void Coffee_Click(object sender, RoutedEventArgs e)
        {

            if (!GameState.HasCoffee)
            {
                GameState.HasCoffee = true;
                MainWindow mainWindow =
        (MainWindow)Application.Current.MainWindow;

                mainWindow.ShowDialog("Našel jsi kafe.");
                kafe.Visibility = Visibility.Hidden;
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow =
                (MainWindow)Application.Current.MainWindow;

            mainWindow.ChangeScene(new Ulice());
        }
    }
}
