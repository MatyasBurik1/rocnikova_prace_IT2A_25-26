﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            GameState.Reset();
            ChangeScene(new scenes.Menu());
        }

        public void ChangeScene(UserControl scene)
        {
            SceneHost.Content = scene;
        }
    }
}
