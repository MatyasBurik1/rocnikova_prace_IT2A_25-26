﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Menu : UserControl
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            GameState.Reset();

            MainWindow mainWindow =
                (MainWindow)Application.Current.MainWindow;

            mainWindow.ChangeScene(new Ulice());
        }
    }
}
