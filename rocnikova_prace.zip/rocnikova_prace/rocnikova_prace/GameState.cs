﻿namespace rocnikova_prace
{
    public static class GameState
    {
        public static bool HasCoffee { get; set; }
        public static bool TalkedToBartender { get; set; }
        public static bool FoundCat { get; set; }

        public static void Reset()
        {
            HasCoffee = false;
            TalkedToBartender = false;
            FoundCat = false;
            inventar.Inventar.Items.Clear();
        }
    }
}
