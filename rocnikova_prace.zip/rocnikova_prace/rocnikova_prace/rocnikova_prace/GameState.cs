﻿namespace rocnikova_prace
{
    public static class GameState
    {
        public static bool HasCoffee { get; set; }
        public static bool HasKey { get; set; }
        public static bool HasBeer { get; set; }
        public static bool TalkedToBohous { get; set; }

        public static void Reset()
        {
            HasCoffee = false;
            HasKey = false;
            HasBeer = false;
            TalkedToBohous = false;
        }
    }
}
