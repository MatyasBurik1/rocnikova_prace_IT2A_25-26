﻿using System.Windows;
using System.Windows.Controls;

namespace rocnikova_prace.scenes
{
    public partial class Ulicka : UserControl
    {
        public Ulicka()
        {
            InitializeComponent();
        }

        private void Cat_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow)
                .ChangeScene(new Konec());
        }
    }
}
