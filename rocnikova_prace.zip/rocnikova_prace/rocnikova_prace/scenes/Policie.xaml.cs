﻿using System.Windows;
using System.Windows.Controls;
using rocnikova_prace.inventar;

namespace rocnikova_prace.scenes
{
    public partial class Policie : UserControl
    {
        public Policie()
        {
            InitializeComponent();
        }

        private void Coffee_Click(object sender, RoutedEventArgs e)
        {
            if (!GameState.HasCoffee)
            {
                GameState.HasCoffee = true;
                Inventar.AddItem("Kafe");

                MessageBox.Show("Našel jsi kafe.");
            }
            else
            {
                MessageBox.Show("Kafe už máš.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow =
                (MainWindow)Application.Current.MainWindow;

            mainWindow.ChangeScene(new Ulice());
        }
    }
}
